export const API_IMG =
  'https://res.cloudinary.com/mvximenko/image/upload/jojo/';
